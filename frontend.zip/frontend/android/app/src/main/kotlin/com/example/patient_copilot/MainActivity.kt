package com.example.patient_copilot

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
